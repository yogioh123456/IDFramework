﻿public interface IUpdate
{
    void Update();
}
