﻿public interface IFixedUpdate
{
    void FixedUpdate();
}
