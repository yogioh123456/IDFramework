﻿public interface IApplicationQuit
{
    void OnApplicationQuit();
}
