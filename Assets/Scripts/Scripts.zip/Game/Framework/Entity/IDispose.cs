﻿public interface IDispose
{
    void Dispose();
}
