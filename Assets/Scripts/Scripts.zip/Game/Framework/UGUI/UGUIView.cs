﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UGUIView
{
    public Transform transform;
    public GameObject gameObject;

    public virtual void Init() { }
}
