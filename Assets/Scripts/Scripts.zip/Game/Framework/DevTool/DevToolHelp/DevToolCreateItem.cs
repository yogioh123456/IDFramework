﻿
[DevPriority(4)]
public class DevToolCreateItem {
    [DevConsole("创建物品/乐高拉钩(Host)")]
    public static void CreateLego() {

    }
}
