﻿
[DevPriority(1)]
public class DevToolRole {
    private static bool isLock;
    
    [DevConsole("角色/锁血心情")]
    public static void LockHPAndMood() {

    }
    
    [DevConsole("角色/飞行模式")]
    public static void FlyMode() {

    }
}
