﻿
[DevPriority(0)]
public class DevToolTest {
    [DevConsole("战场相关/起飞")]
    public static void OnStartFly() {

    }

    [DevConsole("战场相关/速度恢复")]
    public static void GameSpeedReset() {

    }
}
