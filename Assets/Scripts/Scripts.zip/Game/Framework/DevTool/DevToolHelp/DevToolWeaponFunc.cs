﻿#if !CLOSE_TESTTOOL

[DevPriority(2)]
public class DevToolWeaponFunc {
    [DevConsole("武器功能/开关弹道轨迹")]
    public static void ShowBulletRail() {
        
    }
    
    [DevConsole("武器功能/清除子弹轨迹")]
    public static void ClearBulletRail() {
        
    }
}
#endif