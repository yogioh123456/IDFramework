﻿/// <summary>
/// 测试模式
/// </summary>
public class DevToolConfig {

}
