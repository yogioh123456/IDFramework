﻿using UnityEngine;

public class MainLogic {
    
    /// <summary>
    /// 游戏主逻辑入口
    /// </summary>
    public void Init()
    {
        Debug.Log("框架成功运行");
    }
}
